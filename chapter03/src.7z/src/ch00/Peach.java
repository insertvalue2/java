package ch00;

public class Peach extends Fruit {
	
//	String name; 
//	int price; 
//	int fresh; 
	
	public Peach() {
		name = "복숭아";
		price = 5000;
		fresh = 90;
	}
	
}
