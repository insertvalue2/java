package ch00;

public class Banana extends Fruit {

//	String name;
//	int price;
//	int fresh;

	// 다운캐스팅 설명시 추가

	String origin;

	public Banana() {
		name = "바나나";
		price = 3000;
		fresh = 100;
		origin = "태국";
	}
	
}
