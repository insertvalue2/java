package ch00;

public class MainTest1 {

	public static void main(String[] args) {
		
		Banana banana = new Banana();
		Peach peach = new Peach();
		
		banana.showInfo();
		System.out.println("---------");
		peach.showInfo();
		
		
		

	}

}
